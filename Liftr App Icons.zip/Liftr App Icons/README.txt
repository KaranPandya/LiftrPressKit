Liftr App Icons
===============

The Liftr app icon for iOS 27 in six appearances: default, dark, clear (light and dark) and tinted (light and dark). PNG, 1024 x 1024, transparent corners.

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
