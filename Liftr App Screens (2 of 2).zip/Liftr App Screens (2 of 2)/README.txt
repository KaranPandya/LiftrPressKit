Liftr App Screens (2 of 2)
==========================

Full-size screens straight from the app, without captions or device frames, one folder per area. iPhone screens are 1260 x 2736 (iPhone Air), Apple Watch screens 396 x 484 and iPad screens 2752 x 2064.

This is part 2 of 2. It contains: iOS Features, iPad.

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
