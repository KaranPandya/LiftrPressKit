Liftr App Screens - Dark Mode
=============================

The same English app screens as "Liftr App Screens", in the app's dark mode, one folder per area, with the same file names. iPhone screens only, 1260 x 2736 (iPhone Air).

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
