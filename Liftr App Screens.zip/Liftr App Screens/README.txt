Liftr App Screens
=================

Full-size screens straight from the app in English, without captions or device frames, one folder per area. iPhone screens are 1260 x 2736 (iPhone Air), Apple Watch screens 396 x 484 and iPad screens 2752 x 2064.

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
