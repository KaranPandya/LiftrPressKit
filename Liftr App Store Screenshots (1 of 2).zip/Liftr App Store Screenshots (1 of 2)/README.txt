Liftr App Store Screenshots (1 of 2)
====================================

Captioned screenshots in App Store format, one folder per area of the app. iPhone images are 1242 x 2688 and Apple Watch images are 1242 x 1998. Each file is named after its caption.

This is part 1 of 2. It contains: Account and Data, Apple Watch, Coach, Dashboard and Graphs, Exercises and Equipment, Templates and Programs.

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
