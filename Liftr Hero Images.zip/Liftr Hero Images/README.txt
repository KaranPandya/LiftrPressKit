Liftr Hero Images
=================

Wide images of Liftr on iPhone, iPad and Apple Watch for articles and headers, plus the 1200 x 630 social share image. One image has a transparent background.

Provided for press and editorial coverage of Liftr. Liftr is made by KPMB Studio.
Questions or requests: kpmbstudio@gmail.com
More: https://liftr.site/press
